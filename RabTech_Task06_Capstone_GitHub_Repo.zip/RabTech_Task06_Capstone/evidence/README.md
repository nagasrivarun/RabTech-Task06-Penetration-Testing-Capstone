# Evidence folder
Add original evidence after confirming it contains no secrets or unrelated personal data.
Suggested subfolders: `network/` for Nmap outputs and sanitized captures; `application/` for SQLi, stored XSS, reflected XSS, and View Basket screenshots.
Do not fabricate missing evidence. Do not publish session tokens, passwords, or real personal data.
