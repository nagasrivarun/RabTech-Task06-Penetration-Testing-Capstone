# Finding Notes

## NET-01 — Legacy and broad service exposure
Observed: 23 open TCP ports and multiple open/open|filtered UDP ports on isolated Metasploitable 2. Risk: expanded attack surface. Fix: isolate, disable unnecessary listeners, patch/replace unsupported services, and filter traffic. Retest with repeat scans.

## APP-01 — SQL injection authentication bypass
Observed: Juice Shop Login Admin challenge success after the local training payload. Fix: parameterized queries, least-privileged database account, generic errors, regression tests. Retest: payload fails while valid login works.

## APP-02 — Persisted/API-only XSS
Observed: benign alert payload stored in local product description triggered an alert on product view. Fix: safe text rendering, contextual encoding, allowlist sanitization only when needed, CSP as defense in depth. Retest: payload is inert.

## APP-03 — Reflected XSS
Observed: benign alert payload in local tracking-result id parameter triggered an alert. Earlier search-box attempt did not trigger and is not counted. Fix: contextual encoding, safe DOM APIs, input validation, CSP. Retest: no script executes.

## APP-04 — BOLA/IDOR basket access
Observed: Juice Shop View Basket challenge success with local test accounts. Fix: server-side ownership/role checks on every API operation. Retest: cross-account reads/writes denied.
