# RabTech Task 06 — Penetration Testing Capstone

This repository accompanies the trainee report for authorized lab exercises.

## Contents
- `reports/RabTech_Task06_Penetration_Testing_Capstone_Report.pdf` — report for mentor review.
- `findings/risk_matrix.csv` — provisional finding register.
- `findings/finding-notes.md` — observed results, controls, and retest criteria.
- `remediation/secure_patterns.md` — defensive code patterns.
- `evidence/README.md` — instructions for adding original evidence.

## Scope
- Metasploitable 2: `192.168.56.102` on isolated VirtualBox Host-Only Network.
- Local OWASP Juice Shop: `http://localhost:3000`.
- No production targets were tested.

CVSS scores are provisional trainee estimates. Copy original evidence into the evidence folders before final mentor review. Never publish passwords, tokens, private keys, or unsanitized captures.
