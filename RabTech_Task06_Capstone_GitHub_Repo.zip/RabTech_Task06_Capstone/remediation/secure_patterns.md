# Defensive Remediation Patterns

## SQL injection: parameterized query
```python
cursor.execute("SELECT id FROM users WHERE email = %s", (email,))
```

## BOLA / IDOR: enforce ownership server-side
```python
basket = repository.get_basket(basket_id)
if basket is None or basket.user_id != current_user.id:
    abort(404)
```
`current_user` must come from verified server-side authentication, not a request-supplied ID.

## XSS: render as text
```javascript
element.textContent = untrustedDescription;
```
Avoid `innerHTML` for untrusted data. If rich HTML is required, use a maintained allowlist sanitizer.

## Password hashing
```python
hashed = bcrypt.hashpw(password.encode(), bcrypt.gensalt(rounds=12))
valid = bcrypt.checkpw(candidate.encode(), hashed)
```

## Key management
- Use managed KMS/HSM or OS secret storage in production.
- Do not commit keys, tokens, or `.env` secrets.
- AES-GCM requires a fresh random nonce per encryption under the same key.
- Use key versions and a documented rotation/revocation procedure.
